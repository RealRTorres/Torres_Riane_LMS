package edu.valencia.lms.client.chapter33;

import edu.valencia.lms.server.chapter33.Server;

public class Main {
    public static void main(String[] args) {
        Client.main(args);
    }
}
