package edu.valencia.lms.server.chapter33;

public class Main {

    public static void main(String[] args) {
        Server.main(args);
    }
}
